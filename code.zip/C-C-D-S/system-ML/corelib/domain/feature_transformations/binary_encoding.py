# -*- coding: utf-8 -*-

import pandas as pd
from pandera.typing import Series


def is_weekday(tx_datetime: Series[pd.Timestamp]) -> Series[int]:
    
    return (tx_datetime.dt.weekday >= 5).astype(int)


def is_night(tx_datetime: Series[pd.Timestamp]) -> Series[int]:
    
    return (tx_datetime.dt.hour <= 6).astype(int)
