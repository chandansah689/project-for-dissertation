# -*- coding: utf-8 -*-

from __future__ import annotations

import enum

from corelib.data_repositories.data_repository_params import (
    LocalParams,
    SyntheticParams,
)
from corelib.data_repositories.data_reposotory import DataRepository
from corelib.data_repositories.local_repository import Local
from corelib.data_repositories.synthetic_data_repository import Synthetic


class DataRepositoryType(str, enum.Enum):
    

    SYNTHETIC: DataRepositoryType = "SYNTHETIC"
    LOCAL: DataRepositoryType = "LOCAL"


class DataRepositoryFactory:
   
    def __init__(self):
       
        self._params = {
            DataRepositoryType.SYNTHETIC: SyntheticParams,
            DataRepositoryType.LOCAL: LocalParams,
        }
        self._catalogue = {
            DataRepositoryType.SYNTHETIC: Synthetic,
            DataRepositoryType.LOCAL: Local,
        }

    def create(
        self, data_repository_type: DataRepositoryType
    ) -> DataRepository:
       
        params = self._params.get(data_repository_type, None)

        if params is None:
            raise NotImplementedError(
                f"{data_repository_type} parameters not implemented"
            )

        data_repository = self._catalogue.get(data_repository_type, None)

        if data_repository is None:
            raise NotImplementedError(
                f"{data_repository_type} not implemented"
            )

        return data_repository(**params().__dict__)
