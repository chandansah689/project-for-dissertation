# -*- coding: utf-8 -*-

from abc import (
    ABC,
    abstractmethod,
)

import pandas as pd


class DataRepository(ABC):
   

    @abstractmethod
    def load_data(self) -> pd.DataFrame:
       
        raise NotImplementedError

    @abstractmethod
    def preprocess(self, data: pd.DataFrame) -> pd.DataFrame:
        
        raise NotImplementedError
