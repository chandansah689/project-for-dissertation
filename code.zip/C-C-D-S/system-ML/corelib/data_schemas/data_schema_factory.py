# -*- coding: utf-8 -*-

from typing import Dict

from corelib import data_repositories as dr
from corelib.data_schemas.data_schema import BaseSchema
from corelib.data_schemas.local_schema import (
    LocalCustomerIDSchema,
    LocalFeaturesSchema,
    LocalTargetSchema,
    LocalTimeStampSchema,
)
from corelib.data_schemas.synthetic_schema import (
    SyntheticCustomerIDSchema,
    SyntheticFeaturesSchema,
    SyntheticTargetSchema,
    SyntheticTimeStampSchema,
)


class DataSchemaFactory:
    """Data Schema factory."""

    def __init__(self):
       
        self._catalogue = {
            dr.DataRepositoryType.SYNTHETIC: {
                "feature_space": SyntheticFeaturesSchema,
                "target": SyntheticTargetSchema,
                "timestamp": SyntheticTimeStampSchema,
                "customer_id": SyntheticCustomerIDSchema,
            },
            dr.DataRepositoryType.LOCAL: {
                "feature_space": LocalFeaturesSchema,
                "target": LocalTargetSchema,
                "timestamp": LocalTimeStampSchema,
                "customer_id": LocalCustomerIDSchema,
            },
        }

    def create(
        self, data_repository_type: dr.DataRepositoryType
    ) -> Dict[str, BaseSchema]:
        
        data_schemas = self._catalogue.get(data_repository_type, None)

        if data_schemas is None:
            raise NotImplementedError(
                f"{data_repository_type} not implemented"
            )

        return data_schemas
