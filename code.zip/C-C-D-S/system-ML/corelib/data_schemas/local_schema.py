# -*- coding: utf-8 -*-

import pandera as pa
from pandera.typing import (
    DateTime,
    Float,
    Int,
    Series,
)

from corelib.data_schemas.data_schema import BaseSchema


class LocalFeaturesSchema(BaseSchema):
    """Local feature space schema."""

    tx_amount: Series[Float] = pa.Field(nullable=False)

    # Spending habits amount
    customer_id_mean_tx_amount_1_days: Series[Float] = pa.Field(nullable=False)
    customer_id_mean_tx_amount_7_days: Series[Float] = pa.Field(nullable=False)
    customer_id_mean_tx_amount_30_days: Series[Float] = pa.Field(
        nullable=False
    )

    # Spending habits # transactions
    customer_id_count_tx_amount_1_minutes: Series[Float] = pa.Field(
        nullable=False
    )
    customer_id_count_tx_amount_5_minutes: Series[Float] = pa.Field(
        nullable=False
    )
    customer_id_count_tx_amount_10_minutes: Series[Float] = pa.Field(
        nullable=False
    )

    sector_id_mean_tx_fraud_1_days: Series[Float] = pa.Field(nullable=False)
    sector_id_mean_tx_fraud_7_days: Series[Float] = pa.Field(nullable=False)
    sector_id_mean_tx_fraud_30_days: Series[Float] = pa.Field(nullable=False)

    customer_id_mean_tx_fraud_1_days: Series[Float] = pa.Field(nullable=False)
    customer_id_mean_tx_fraud_7_days: Series[Float] = pa.Field(nullable=False)
    customer_id_mean_tx_fraud_30_days: Series[Float] = pa.Field(nullable=False)

    # tx_day_linear: Series[Int] = pa.Field(nullable=False)
    # tx_time_cos: Series[Float] = pa.Field(nullable=False)
    # tx_time_sin: Series[Float] = pa.Field(nullable=False)


class LocalTargetSchema(BaseSchema):
    """Local target schema."""

    tx_fraud: Series[Int] = pa.Field(nullable=False)


class LocalTimeStampSchema(BaseSchema):
    """Local TimeStam schema."""

    tx_datetime: Series[DateTime] = pa.Field(nullable=False)


class LocalCustomerIDSchema(BaseSchema):
    """Synthetic TimeStam schema."""

    customer_id: Series[Int] = pa.Field(nullable=False)
