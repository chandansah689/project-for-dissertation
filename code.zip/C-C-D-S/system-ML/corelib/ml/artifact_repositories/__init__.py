# -*- coding: utf-8 -*-

from corelib.ml.artifact_repositories.artifact_repository import ArtifactRepo

__all__ = ["ArtifactRepo"]
