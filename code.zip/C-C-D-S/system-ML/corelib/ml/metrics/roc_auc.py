# -*- coding: utf-8 -*-

from typing import (
    Any,
    Dict,
    Optional,
)

from sklearn.metrics import roc_auc_score

from corelib.ml.metrics.metric import (
    Metric,
    Results,
    TrueValues,
)


class ROCAUCScore(Metric):
   
    name: str = "roc_auc_score"
    params: Optional[Dict[str, Any]] = None

    def measure(
        self,
        results: Results,
        true_values: TrueValues,
        plot_results: bool = False,
    ) -> float:
       
        if not self.params:
            self.params = {}

        score = roc_auc_score(
            y_true=true_values.tx_fraud,
            y_score=results.scores,
            **self.params,
        )

        return score
