# -*- coding: utf-8 -*-
"""Data Storage modules.

Created on: 10/10/23
@author: Heber Trujillo <heber.trj.urt@gmail.com>
Licence,
"""
