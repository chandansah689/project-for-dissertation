# -*- coding: utf-8 -*-

import pytest

from corelib.entrypoints.routes import get_estimator
from corelib.ml.estimators.estimator import Estimator


@pytest.mark.unit
def test_initialization() -> None:
    """Test the estimator singleton is correctly instantiated."""
    assert isinstance(get_estimator(), Estimator)
