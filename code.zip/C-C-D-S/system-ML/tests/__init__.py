# -*- coding: utf-8 -*-
"""Test suit.

Created on: 30/9/23
@author: Heber Trujillo <heber.trj.urt@gmail.com>
Licence,
"""
