
* **Dockerfile**: Configuration file for creating a Docker container. 
* **docker-entrypoint.sh**: Entry script for the Docker container.
* **docker-compose.yml**: Configuration file to define and run multi-container Docker applications.
* **LICENSE**: Project's license. 
* **README.md**: (You're here!) Provides a high-level overview of the repository.
* * **corelib**: The backbone of our system. 
  * **config**: System-wide configurations.
  * **data_repositories**: Data interfaces and implementations.
  * **data_schemas**: Data validation and schema-related utilities.
  * **domain**: Core business logic, feature transformations, and domain-related utilities.
  * **entrypoints**: Exposes the API of our application.
  * **ml**: All things related to machine learning, e.g., Algorithms, metrics, transformers and more.
  * **services**: Houses core service logic for predictions.
  * **utils**: Utility scripts for logging, caching, and more. 
* **train.py**: Script for training the models.
* **log**: Contains log files. 
* **poetry.lock & pyproject.toml**: Poetry configuration and lock files for package management. 
* **pytest**.ini: Configuration file for pytest. 
* **tests**: Contains unit tests for the project.
* **imgs**: Any images related to the project (e.g., system diagrams).


## How to Run Scripts 

## Docker

### Prerequisites

Ensure you have Docker installed on your machine. If not, you can download and install it from [here](https://docs.docker.com/get-docker/).

#### Build the Docker Image

1. Navigate to the directory containing the project
    ```zsh
    cd /path/to/fraud-detection-system
    ```

2. Build the Docker image. We'll name it fraud-detection-system:
    ```zsh
    docker build -t fraud-detection-system:latest . 
    ```

Note: The `.` at the end indicates the current directory which contains your Dockerfile.

#### Running the Container

With the provided `docker-compose.yml` file, you can easily orchestrate the setup of services and their dependencies. This method offers a more organized and streamlined approach compared to individual `docker run` commands.

1. **Start All Services**:

    To start all services defined in the `docker-compose.yml`:
    ```zsh
    docker-compose up
    ```

    By default, `docker-compose up` will start all services in the background. If you want to run them in the foreground to see the logs, add the `-d` flag:
    ```zsh
    docker-compose up -d
    ```

2. **Set Up and Train**:

    To only initiate the training service:
    ```zsh
    docker-compose up training
    ```

3. **Test Model Prediction Consistency**:

    Before moving to the serving stage, testing the model's prediction consistency between training and inference pipelines is crucial; it is worthwhile noting that latency tests are on the backlog. To do so, it is possible to use the deployment service independently:
    ```zsh
    docker-compose up serve_dev
    ```

4. **Serve the Model in Development Mode**:

    To serve the model using FastAPI after training:
    ```zsh
    docker-compose up serve_dev
    ```

    Once up, you can access the API at `http://localhost:8000/docs`.

4. **Stopping and Removing Containers**:

    To stop and remove all containers, networks, and volumes defined in the `docker-compose.yml`:
    ```zsh
    docker-compose down
    ```

    If you also want to remove the images used by the services, add the `--rmi all` flag:
    ```zsh
    docker-compose down --rmi all
    ```

Alternatively, if you're not using `docker-compose`, you can run the container using the given entry points.

1. **Train**
This entry point runs the training script.
    ```zsh
    docker run -it --name my_fraud_detection_container fraud-detection-system:latest train
    ```

2. Train with HPO (Hyperparameter Optimization):
    ```zsh
    docker run -it --name my_fraud_detection_container fraud-detection-system:latest train_hpo
    ```

#### Notes:

* **Docker Flags**:
  * `-it`: These flags are combined to allow for an interactive session.

      * The `-i` flag keeps the standard input (stdin) open, allowing you to interact with any processes inside the container.
      * The `-t` flag allocates a pseudo-TTY, simulating a terminal environment inside the container.

  Together, the `-it` flags let you view logs and output from the execution directly in your terminal, making it feel as though the processes inside the container are running in your terminal session.

* **Container Naming**:
    * `--name my_fraud_detection_container`: This flag assigns a specific name (`my_fraud_detection_container`) to your container. Naming your containers makes it easier to manage and reference them later. Without specifying a name, Docker would assign a random name to the container.

* **Docker Compose**:
  * Using `docker-compose` helps manage multi-container applications effortlessly. It uses the provided `docker-compose.yml` to set up, link, and manage the lifecycles of the containers.
